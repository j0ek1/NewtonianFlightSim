using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControl : MonoBehaviour
{
    public RocketPhysics rocket;

    void FixedUpdate()
    {
        transform.position = new Vector3(rocket.transform.position.x, rocket.transform.position.y, rocket.transform.position.z - 10f);
    }
}
