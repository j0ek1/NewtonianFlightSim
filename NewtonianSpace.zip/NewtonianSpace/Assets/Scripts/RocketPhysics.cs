using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RocketPhysics : MonoBehaviour
{
    // vector calculations
    public VectorCalc vcalc;

    // linear motion
    public Vector3 force = new Vector3(0, 0, 0);
    Vector3 acceleration;
    Vector3 velocity;
    public float mass;
    private Vector3 gravity = new Vector3(0, -9.8f, 0);

    // angular motion
    public Vector3 torque;
    public Vector3 angularAcceleration;
    public Vector3 angularVelocity;
    public float inertia;

    // magnitude of force to be applied
    private float fMagnitude = 0f;
    // thrusters
    public GameObject thruster1;
    public GameObject thruster2;
    public GameObject thruster3;
    public GameObject thruster4;
    public GameObject thruster1mid;
    public GameObject thruster2mid;
    public GameObject thruster3mid;
    public GameObject thruster4mid;
    public GameObject thruster1body;
    public GameObject thruster2body;
    public GameObject thruster3body;
    public GameObject thruster4body;

    // active thruster variables
    private Vector3 kw = new Vector3(0, 0, 0); // directional vectors
    private Vector3 ka = new Vector3(0, 0, 0);
    private Vector3 ks = new Vector3(0, 0, 0);
    private Vector3 kd = new Vector3(0, 0, 0);
    private Vector3 pw = new Vector3(0, 0, 0); // positional vectors
    private Vector3 pa = new Vector3(0, 0, 0);
    private Vector3 ps = new Vector3(0, 0, 0);
    private Vector3 pd = new Vector3(0, 0, 0);

    // thruster magnitudes
    private float fMagnitude1 = 0f;
    private float fMagnitude2 = 0f;
    private float fMagnitude3 = 0f;
    private float fMagnitude4 = 0f;

    // height value text
    public Text height;

    void Start()
    {

    }

    void Update()
    {

    }

    void FixedUpdate()
    {
        // linear motion calculations
        acceleration = force / mass;
        velocity += acceleration * Time.fixedDeltaTime;
        transform.position += velocity * Time.fixedDeltaTime;

        // gravity
        velocity += gravity * Time.fixedDeltaTime;

        // point of impact representation calculated through active thruster positions
        Vector3 point;
        point = VectorCalc.Addition(VectorCalc.Addition(VectorCalc.Addition(pw, pa), ps), pd);

        // angular motion calculations
        torque = VectorCalc.Force2Torque(force, transform.position, point);
        angularAcceleration = torque / inertia;
        angularVelocity += angularAcceleration * Time.fixedDeltaTime;

        // euler angle to quaternion calculation
        Quat q = new Quat();
        float angularVMag = VectorCalc.Magnitude(angularVelocity * Time.fixedDeltaTime);
        q.w = Mathf.Cos(angularVMag / 2);
        q.v.x = Mathf.Sin(angularVMag / 2) * (angularVelocity * Time.fixedDeltaTime).x / angularVMag;
        q.v.y = Mathf.Sin(angularVMag / 2) * (angularVelocity * Time.fixedDeltaTime).y / angularVMag;
        q.v.z = Mathf.Sin(angularVMag / 2) * (angularVelocity * Time.fixedDeltaTime).z / angularVMag;

        // applying rotation to the rocket
        Quat tr = new Quat();
        tr.w = transform.rotation.w;
        tr.v.x = transform.rotation.x;
        tr.v.y = transform.rotation.y;
        tr.v.z = transform.rotation.z;
        Quat targetR = q * tr;       
        transform.rotation = VectorCalc.ToUnityQuaternion(targetR);

        // thruster controls
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.Space))
        {
            fMagnitude += 0.5f; // magnitude acceleration
            if (fMagnitude > 20f)
            {
                fMagnitude = 20f; // maximum magnitude is 20
            }

            if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.Space)) // thruster 1
            {
                ka = VectorCalc.Subtraction(thruster1mid.transform.position, thruster1.transform.position); // directional vector
                pa = thruster1.transform.position; // positional vector

                fMagnitude1 += 0.5f;
                if (fMagnitude1 > 20f)
                {
                    fMagnitude1 = 20f;
                }
                thruster1body.GetComponent<Renderer>().material.color = new Color(1f, 1f - (fMagnitude1 / 20f), 1f - (fMagnitude1 / 20f)); // colour display
            }
            else
            {
                ka = new Vector3(0, 0, 0);
                pa = new Vector3(0, 0, 0);

                fMagnitude1 -= 1f;
                if (fMagnitude1 < 0f)
                {
                    fMagnitude1 = 0f;
                }
                thruster1body.GetComponent<Renderer>().material.color = new Color(1f, 1f - (fMagnitude1 / 20f), 1f - (fMagnitude1 / 20f));
            }

            if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.Space)) // thruster 2
            {
                kw = VectorCalc.Subtraction(thruster2mid.transform.position, thruster2.transform.position); // directional vector
                pw = thruster2.transform.position; // positional vector

                fMagnitude2 += 0.5f;
                if (fMagnitude2 > 20f)
                {
                    fMagnitude2 = 20f;
                }
                thruster2body.GetComponent<Renderer>().material.color = new Color(1f, 1f - (fMagnitude2 / 20f), 1f - (fMagnitude2 / 20f)); // colour display
            }
            else
            {
                kw = new Vector3(0, 0, 0);
                pw = new Vector3(0, 0, 0);

                fMagnitude2 -= 1f;
                if (fMagnitude2 < 0f)
                {
                    fMagnitude2 = 0f;
                }
                thruster2body.GetComponent<Renderer>().material.color = new Color(1f, 1f - (fMagnitude2 / 20f), 1f - (fMagnitude2 / 20f));
            }

            if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.Space)) // thruster 3
            {
                kd = VectorCalc.Subtraction(thruster3mid.transform.position, thruster3.transform.position); // directional vector
                pd = thruster3.transform.position; // positional vector

                fMagnitude3 += 0.5f;
                if (fMagnitude3 > 20f)
                {
                    fMagnitude3 = 20f;
                }
                thruster3body.GetComponent<Renderer>().material.color = new Color(1f, 1f - (fMagnitude3 / 20f), 1f - (fMagnitude3 / 20f)); // colour display
            }
            else
            {
                kd = new Vector3(0, 0, 0);
                pd = new Vector3(0, 0, 0);

                fMagnitude3 -= 1f;
                if (fMagnitude3 < 0f)
                {
                    fMagnitude3 = 0f;
                }
                thruster3body.GetComponent<Renderer>().material.color = new Color(1f, 1f - (fMagnitude3 / 20f), 1f - (fMagnitude3 / 20f));
            }

            if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.Space)) // thruster 4
            {
                ks = VectorCalc.Subtraction(thruster4mid.transform.position, thruster4.transform.position); // directional vector
                ps = thruster4.transform.position; // positional vector

                fMagnitude4 += 0.5f;
                if (fMagnitude4 > 20f)
                {
                    fMagnitude4 = 20f;
                }
                thruster4body.GetComponent<Renderer>().material.color = new Color(1f, 1f - (fMagnitude4 / 20f), 1f - (fMagnitude4 / 20f)); // colour display
            }
            else
            {
                ks = new Vector3(0, 0, 0);
                ps = new Vector3(0, 0, 0);

                fMagnitude4 -= 1f;
                if (fMagnitude4 < 0f)
                {
                    fMagnitude4 = 0f;
                }
                thruster4body.GetComponent<Renderer>().material.color = new Color(1f, 1f - (fMagnitude4 / 20f), 1f - (fMagnitude4 / 20f));
            }

            // final force applied
            force = VectorCalc.Normalized(VectorCalc.Addition(VectorCalc.Addition(VectorCalc.Addition(kw, ka), ks), kd)) * fMagnitude;
        }
        else // if no thruster is active
        {
            fMagnitude -= 2f;
            if (fMagnitude < 0f)
            {
                fMagnitude = 0f;
            }
            fMagnitude1 -= 2f;
            if (fMagnitude1 < 0f)
            {
                fMagnitude1 = 0f;
            }
            thruster1body.GetComponent<Renderer>().material.color = new Color(1f, 1f - (fMagnitude1 / 20f), 1f - (fMagnitude1 / 20f));
            fMagnitude2 -= 2f;
            if (fMagnitude2 < 0f)
            {
                fMagnitude2 = 0f;
            }
            thruster2body.GetComponent<Renderer>().material.color = new Color(1f, 1f - (fMagnitude2 / 20f), 1f - (fMagnitude2 / 20f));
            fMagnitude3 -= 2f;
            if (fMagnitude3 < 0f)
            {
                fMagnitude3 = 0f;
            }
            thruster3body.GetComponent<Renderer>().material.color = new Color(1f, 1f - (fMagnitude3 / 20f), 1f - (fMagnitude3 / 20f));
            fMagnitude4 -= 2f;
            if (fMagnitude4 < 0f)
            {
                fMagnitude4 = 0f;
            }
            thruster4body.GetComponent<Renderer>().material.color = new Color(1f, 1f - (fMagnitude4 / 20f), 1f - (fMagnitude4 / 20f));

            force = new Vector3(0, 0, 0);
        }
        height.text = Mathf.Round(transform.position.y).ToString();
    }
}