using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VectorCalc : MonoBehaviour
{
    public static Vector3 Addition(Vector3 a, Vector3 b) // vector addition
    {
        Vector3 sr;
        sr = new Vector3(a.x + b.x, (a.y + b.y), (a.z + b.z));
        return sr;
    }

    public static Vector3 Subtraction(Vector3 a, Vector3 b) // vector subtraction
    {
        Vector3 sr;
        sr = new Vector3((a.x - b.x), (a.y - b.y), (a.z - b.z));
        return sr;
    }

    public static Vector3 CrossProduct(Vector3 a, Vector3 b) // cross product formula
    {
        Vector3 cpr;
        cpr = new Vector3((a.y * b.z) - (a.z * b.y), -((a.x * b.z) - (a.z * b.x)), +((a.x * b.y) - (a.y * b.x)));
        return cpr;
    }

    public static float DotProduct(Vector3 a, Vector3 b) // dot product formula
    {
        float dpr;
        dpr = (a.x * b.x) + (a.y * b.y) + (a.z * b.z);
        return dpr;
    }

    public static float Magnitude(Vector3 a) // vector magnitude calculation
    {
        float mr;
        mr = Mathf.Sqrt((a.x * a.x) + (a.y * a.y) + (a.z * a.z));
        return mr;
    }

    public static Vector3 Normalized(Vector3 a) // normalized vector calculation
    {
        Vector3 nr;
        float vv = Mathf.Sqrt(Mathf.Pow(a.x, 2f) + Mathf.Pow(a.y, 2f) + Mathf.Pow(a.z, 2f));
        nr = new Vector3(a.x/vv, a.y/vv, a.z/vv);
        return nr;
    }

    public static Vector3 Force2Torque(Vector3 f, Vector3 c, Vector3 p) // convert force to torque
    {
        Vector3 tr;
        tr = CrossProduct(f, (Subtraction(c, p)));
        return tr;
    }

    public static float Deg2Rad(float a) // convert degrees to radians
    {
        float rad;
        rad = a * (Mathf.PI / 180f);
        return rad;
    }

    public static Quaternion ToUnityQuaternion(Quat q) // convert own Quat class to Unity's Quaternion
    {
        Quaternion qr = new Quaternion();
        qr.w = q.w;
        qr.x = q.v.x;
        qr.y = q.v.y;
        qr.z = q.v.z;
        return qr;
    }
}
public class Quat
{
    public float w;
    public Vector3 v;

    public static Quat operator *(Quat lhs, Quat rhs)
    {
        Quat r = new Quat();
        r.w = (rhs.w * lhs.w) - (VectorCalc.DotProduct(rhs.v, lhs.v));
        r.v = (rhs.w * lhs.v) + (lhs.w * rhs.v) + VectorCalc.CrossProduct(lhs.v, rhs.v);
        return r;
    }
}